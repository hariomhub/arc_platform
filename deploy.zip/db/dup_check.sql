-- Check for duplicate titles in key tables
SELECT 'events duplicates' AS chk, title, COUNT(*) AS c FROM events GROUP BY title HAVING c > 1
UNION ALL
SELECT 'nominees duplicates', name, COUNT(*) FROM nominees GROUP BY name HAVING COUNT(*) > 1
UNION ALL
SELECT 'resources duplicates', title, COUNT(*) FROM resources GROUP BY title HAVING COUNT(*) > 1
UNION ALL
SELECT 'team duplicates', name, COUNT(*) FROM team_members GROUP BY name HAVING COUNT(*) > 1
UNION ALL
SELECT 'products duplicates', name, COUNT(*) FROM products GROUP BY name HAVING COUNT(*) > 1
UNION ALL
SELECT 'awards duplicates', name, COUNT(*) FROM awards GROUP BY name HAVING COUNT(*) > 1
UNION ALL
SELECT 'qna duplicates', title, COUNT(*) FROM qna_posts GROUP BY title HAVING COUNT(*) > 1;
