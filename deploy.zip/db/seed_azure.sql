-- ============================================================
-- ARC Platform — Seed Data for Azure MySQL
-- Run: cmd /c "mysql -h racdatabase.mysql.database.azure.com -u racdbadmin -padminrac@321 racdatabase < db/seed_azure.sql"
-- ============================================================

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. TEAM MEMBERS
-- ─────────────────────────────────────────────────────────────────────────────
DELETE FROM team_members;

INSERT INTO team_members (name, role, photo_url, linkedin_url, bio) VALUES
-- Leadership
('Dr. Sarah Chen', 'Head of AI Research', 'https://randomuser.me/api/portraits/women/14.jpg', 'https://linkedin.com/', 'Dr. Chen leads our core research initiatives focusing on neural network safety and interpretability.'),
('Marcus Johnson', 'Chief Risk Officer', 'https://randomuser.me/api/portraits/men/32.jpg', 'https://linkedin.com/', 'Marcus brings 15 years of standard risk management and applies it to modern AI systems governance.'),
('Elena Rodriguez', 'Ethics Lead', 'https://randomuser.me/api/portraits/women/68.jpg', 'https://linkedin.com/', 'Elena focuses on algorithmic bias, fairness, and the ethical deployment of autonomous systems.'),
('David Kim', 'Senior Security Engineer', 'https://randomuser.me/api/portraits/men/46.jpg', 'https://linkedin.com/', 'Specializes in red-teaming LLMs and identifying vulnerabilities in production ML pipelines.'),
('Priya Sharma', 'Director of Policy', 'https://randomuser.me/api/portraits/women/59.jpg', 'https://linkedin.com/', 'Priya bridges the gap between technical AI capabilities and emerging global regulatory frameworks.'),
('Alex Thompson', 'Lead Auditor', 'https://randomuser.me/api/portraits/men/22.jpg', 'https://linkedin.com/', 'Alex develops our proprietary frameworks for conducting comprehensive AI system audits.'),
('Dr. James Wilson', 'Principal Data Scientist', 'https://randomuser.me/api/portraits/men/82.jpg', 'https://linkedin.com/', 'Focuses on privacy-preserving machine learning techniques including federated learning.'),
('Maria Garcia', 'Compliance Manager', 'https://randomuser.me/api/portraits/women/33.jpg', 'https://linkedin.com/', 'Ensures our internal and external operations adhere to the highest international data standards.'),
('Tom Baker', 'Systems Architect', 'https://randomuser.me/api/portraits/men/62.jpg', 'https://linkedin.com/', 'Designs scalable, secure infrastructure for deploying large-scale AI models reliably.'),
('Nina Patel', 'Community Outreach', 'https://randomuser.me/api/portraits/women/11.jpg', 'https://linkedin.com/', 'Engages with external stakeholders, organizing our workshops, seminars, and public forums.'),
-- Industrial AI Experts
('Dr. Robert Chang', 'Industrial Automation Specialist', 'https://randomuser.me/api/portraits/men/15.jpg', 'https://linkedin.com/', 'Robert focuses on the integration of computer vision in smart manufacturing facilities.'),
('Samantha Lee', 'Supply Chain AI Modeler', 'https://randomuser.me/api/portraits/women/24.jpg', 'https://linkedin.com/', 'Samantha builds predictive models to anticipate supply chain disruptions on a global scale.'),
('Prof. Hans Mueller', 'Robotics Integration Lead', 'https://randomuser.me/api/portraits/men/44.jpg', 'https://linkedin.com/', 'Hans ensures safety protocols are strictly followed in human-robot collaborative environments.'),
('Jessica Taylor', 'IoT Edge Computing', 'https://randomuser.me/api/portraits/women/42.jpg', 'https://linkedin.com/', 'Jessica optimizes machine learning models to run efficiently on low-power industrial edge devices.'),
('Oliver Green', 'Predictive Maintenance Lead', 'https://randomuser.me/api/portraits/men/51.jpg', 'https://linkedin.com/', 'Oliver develops acoustic and vibration analysis tools to predict heavy machinery failures.'),
-- Security Team
('Amira Hassan', 'Head of Penetration Testing', 'https://randomuser.me/api/portraits/women/71.jpg', 'https://linkedin.com/', 'Amira specializes in highly complex cyber-physical attacks against emerging AI models.'),
('Daniel Foster', 'Cloud Security Architect', 'https://randomuser.me/api/portraits/men/88.jpg', 'https://linkedin.com/', 'Daniel hardens our cloud training pipelines against external intrusion and internal leakage.'),
('Chloe Davies', 'Cryptography Expert', 'https://randomuser.me/api/portraits/women/8.jpg', 'https://linkedin.com/', 'Chloe is pioneering the use of homomorphic encryption for training models on sensitive health data.'),
('Kevin O''Connor', 'Threat Intelligence Lead', 'https://randomuser.me/api/portraits/men/38.jpg', 'https://linkedin.com/', 'Kevin monitors deep web channels to track emerging adversarial tactics weaponized against AI.'),
('Rachel Zane', 'Incident Response Commander', 'https://randomuser.me/api/portraits/women/92.jpg', 'https://linkedin.com/', 'Rachel orchestrates the council''s rapid response protocol during active security breaches.'),
-- Academic Partners
('Prof. Yuki Tanaka', 'AI Alignment Researcher', 'https://randomuser.me/api/portraits/women/31.jpg', 'https://linkedin.com/', 'Yuki investigates alignment techniques to ensure advanced AI models remain safe and beneficial.'),
('Dr. Liam O''Brien', 'NLP Safety Specialist', 'https://randomuser.me/api/portraits/men/67.jpg', 'https://linkedin.com/', 'Liam analyzes large language models for unexpected emergent behaviours and capability elicitation risks.'),
('Prof. Mei Lin', 'Computational Ethics Chair', 'https://randomuser.me/api/portraits/women/53.jpg', 'https://linkedin.com/', 'Mei develops ethical frameworks for AI decision-making in high-stakes public sector deployments.');

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. EVENTS (upcoming + past)
-- ─────────────────────────────────────────────────────────────────────────────
DELETE FROM events;

INSERT INTO events (title, date, location, description, link, event_category, is_upcoming, is_published) VALUES
-- Upcoming events (future dates)
('EU AI Act Compliance Masterclass', '2026-04-15 14:00:00', 'Online (Zoom)', 'A deep-dive session covering the EU AI Act\'s new enforcement timelines, prohibited practices, and what high-risk system operators must do by August 2026.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'webinar', TRUE, TRUE),
('AI Red-Teaming Workshop: LLM Adversarial Testing', '2026-04-28 10:00:00', 'London, UK (Hybrid)', 'Hands-on workshop where participants learn to identify, exploit, and document adversarial vulnerabilities in large language models deployed in production.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'workshop', TRUE, TRUE),
('AI Governance Podcast: Policy Special', '2026-05-05 09:00:00', 'Online (Podcast)', 'Monthly deep-dive featuring senior policy advisors from the EU AI Office and NIST discussing the global regulatory landscape for foundation models.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'podcast', TRUE, TRUE),
('NIST AI Risk Management Framework v2 Briefing', '2026-05-20 15:00:00', 'Online (Zoom)', 'Council experts walk through the latest revisions to the NIST AI RMF, with practical guidance on gap assessments and implementation roadmaps.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'webinar', TRUE, TRUE),
('Privacy-Preserving AI Seminar', '2026-06-03 13:00:00', 'Singapore (In-Person)', 'An executive seminar exploring federated learning, differential privacy, and synthetic data generation as tools for responsible AI deployment in regulated industries.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'seminar', TRUE, TRUE),
('AI Auditing & Certification Workshop', '2026-06-18 09:30:00', 'Dubai, UAE (Hybrid)', 'Practical workshop on conducting independent AI audits, documenting conformity assessments, and preparing for third-party certification under ISO 42001.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'workshop', TRUE, TRUE),
('Responsible AI in Financial Services Webinar', '2026-07-08 14:00:00', 'Online (Zoom)', 'Specialist session for banking and insurance professionals on model risk management, explainable AI requirements, and SR 11-7 guidance alignment.', 'https://riskaicouncil-fsgmh0erfjh0g6g4.eastasia-01.azurewebsites.net/', 'webinar', TRUE, TRUE),
-- Past events (past dates)
('AI Risk Foundations Bootcamp', '2026-01-20 10:00:00', 'Online (Zoom)', 'Introductory bootcamp covering the fundamentals of AI risk: threat modelling, harm identification, and building an organisational AI governance programme from scratch.', NULL, 'workshop', FALSE, TRUE),
('2025 Annual AI Security Summit', '2025-11-14 09:00:00', 'Washington D.C., USA', 'Our flagship annual summit bringing together 500+ risk professionals, policymakers, and AI researchers for two days of keynotes, panels, and workshops.', NULL, 'seminar', FALSE, TRUE),
('Navigating the EU AI Act: Legal Obligations', '2025-10-09 15:00:00', 'Online (Zoom)', 'Legal-focused webinar breaking down Article 6, Annex III high-risk categories, and conformity assessment obligations for AI system operators and importers.', NULL, 'webinar', FALSE, TRUE),
('AI Model Monitoring in Production', '2025-09-17 13:00:00', 'Online (Zoom)', 'Technical webinar covering data drift detection, model degradation metrics, alerting strategies, and incident response for live AI systems.', NULL, 'webinar', FALSE, TRUE),
('Healthcare AI Ethics Roundtable Podcast', '2025-08-26 09:00:00', 'Online (Podcast)', 'Roundtable discussion with clinical informaticists, bioethicists, and AI developers on accountability, consent, and error attribution in diagnostic AI tools.', NULL, 'podcast', FALSE, TRUE);

-- ─────────────────────────────────────────────────────────────────────────────
-- 3. RESOURCES (frameworks & whitepapers)
-- ─────────────────────────────────────────────────────────────────────────────
DELETE FROM resources WHERE type IN ('framework', 'whitepaper');

INSERT INTO resources (title, description, abstract, file_url, type, status) VALUES
('AI Risk Management Framework v3.0', 'The AI Risk Council''s comprehensive framework for identifying, assessing, and mitigating AI risks across the full system lifecycle. Aligned with NIST AI RMF, ISO 42001, and EU AI Act requirements.', 'This framework provides a structured, four-phase methodology (GOVERN, MAP, MEASURE, MANAGE) for enterprise AI risk programmes. It includes 200+ controls, audit templates, and maturity scoring rubrics validated across 50+ organisations in 20 countries.', NULL, 'framework', 'approved'),
('Generative AI Deployment Risk Assessment Template', 'A ready-to-use risk assessment template specifically designed for organisations deploying large language models and generative AI systems in production environments.', 'Covers data provenance, bias & fairness evaluation, adversarial robustness, privacy leakage, RLHF alignment verification, and supply chain security for foundation model deployments. Includes scoring sheets and remediation guidance.', NULL, 'framework', 'approved'),
('EU AI Act Compliance Checklist 2025', 'A practical compliance checklist for organisations subject to the EU AI Act, covering prohibited practices, high-risk system obligations, and general-purpose AI model requirements.', 'Structured as a gap assessment tool, this checklist maps EU AI Act Articles to operational controls. Includes guidance for Articles 6–51 with a focus on Annex III high-risk categories, transparency obligations, and conformity assessment pathways.', NULL, 'framework', 'approved'),
('The State of AI Governance 2025: Global Survey Report', 'Annual survey of 1,200+ organisations across 40 countries examining AI governance maturity, investment priorities, regulatory readiness, and emerging risk trends.', 'Key findings: 67% of enterprises lack a formal AI incident response plan; only 23% of AI deployments undergo formal risk assessment; model documentation practices remain inconsistent. Includes regional breakdowns and sector-specific analysis.', NULL, 'whitepaper', 'approved'),
('Adversarial AI: Threat Taxonomy & Mitigation Guide', 'A technical whitepaper cataloguing adversarial attack vectors against modern AI systems, with detection strategies and architectural mitigations for each threat class.', 'Covers prompt injection, jailbreaking, model extraction, membership inference, data poisoning, and evasion attacks against vision and language models. Provides a threat-actor capability matrix and practical hardening recommendations for each deployment context.', NULL, 'whitepaper', 'approved'),
('AI Incident Response Playbook', 'A step-by-step incident response playbook tailored for AI system failures, including model hallucinations, bias incidents, security breaches, and regulatory non-compliance events.', 'Adapted from NIST CSF and FIRST PSIRT frameworks for AI-specific incident categories. Includes 12 scenario-specific runbooks, a stakeholder communication template, post-incident review process, and regulatory notification guidance for GDPR, EU AI Act, and US EO 14110.', NULL, 'whitepaper', 'approved'),
('ISO 42001 Implementation Guide', 'A practical implementation guide for organisations pursuing ISO 42001 certification — the international standard for AI management systems.', 'Provides a clause-by-clause implementation guide with worked examples, gap assessment templates, and a sample AI policy suite. Covers AI management system scope, leadership commitment, risk treatment, and performance evaluation requirements.', NULL, 'framework', 'approved'),
('AI Supply Chain Security: Vendor Risk Assessment Guide', 'A structured guide for assessing AI vendors, open-source model providers, and third-party dataset sources as part of an enterprise AI supply chain risk programme.', 'Includes a 150-question vendor questionnaire, scoring methodology, red-flag indicators, and contractual safeguard recommendations. Covers training data provenance, model cards, fine-tuning disclosures, and incident reporting obligations.', NULL, 'whitepaper', 'approved');

SELECT CONCAT('✅ Seed complete. team_members: ', (SELECT COUNT(*) FROM team_members), ', events: ', (SELECT COUNT(*) FROM events), ', resources: ', (SELECT COUNT(*) FROM resources)) AS status;
