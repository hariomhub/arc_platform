-- Migration 005: Membership upgrade applications
-- Tracks executive and founding_member upgrade requests from existing users.
-- Keeps the user's current role/status intact until admin approves.

CREATE TABLE IF NOT EXISTS membership_applications (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    user_id             INT          NOT NULL,
    requested_role      ENUM('executive','founding_member') NOT NULL,

    -- Common fields
    full_name           VARCHAR(255) NOT NULL,
    email               VARCHAR(255) NOT NULL,
    organization_name   VARCHAR(255),
    job_title           VARCHAR(255),
    linkedin_url        VARCHAR(500),
    phone               VARCHAR(50),

    -- Executive-specific
    payment_reference   VARCHAR(100) DEFAULT 'PROMO-100PCT',
    amount_paid         DECIMAL(10,2) DEFAULT 0.00,

    -- Founding member-specific
    professional_bio    TEXT,
    areas_of_expertise  VARCHAR(1000),
    why_founding_member TEXT,
    website_url         VARCHAR(500),
    twitter_url         VARCHAR(500),

    -- Status
    status              ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    admin_notes         TEXT,
    created_at          DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at        DATETIME,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_status        (status),
    INDEX idx_requested_role (requested_role),
    INDEX idx_user_id       (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
