-- ─────────────────────────────────────────────────────────────────────────────
-- Migration 004: Three-Tier Role System
-- Old roles: admin, free_member, paid_member, executive, university, product_company
-- New roles: founding_member (lifetime), executive (3yr), professional (1yr)
-- ─────────────────────────────────────────────────────────────────────────────

-- Step 1: Add membership_expires_at column to users
ALTER TABLE users
  ADD COLUMN membership_expires_at DATETIME NULL DEFAULT NULL
    COMMENT 'NULL = lifetime (founding_member). Set on approval based on role.';

-- Step 2: Migrate existing roles to new system
--   admin → founding_member (lifetime)
--   executive → executive (keep, set 3-year expiry from now)
--   paid_member, university, product_company, free_member → professional (1-year from now)

-- First, temporarily allow both old and new role values
ALTER TABLE users
  MODIFY COLUMN role ENUM(
    'admin','free_member','paid_member','executive','university','product_company',
    'founding_member','professional'
  ) NOT NULL DEFAULT 'professional';

-- Migrate admin → founding_member
UPDATE users SET role = 'founding_member', membership_expires_at = NULL
  WHERE role = 'admin';

-- Migrate all non-executive, non-admin users → professional (1-year from approval date)
UPDATE users
  SET role = 'professional',
      membership_expires_at = CASE
        WHEN status = 'approved' THEN DATE_ADD(COALESCE(updated_at, created_at), INTERVAL 1 YEAR)
        ELSE NULL
      END
  WHERE role IN ('free_member', 'paid_member', 'university', 'product_company');

-- executive stays executive, set 3-year expiry from approval
UPDATE users
  SET membership_expires_at = CASE
        WHEN status = 'approved' THEN DATE_ADD(COALESCE(updated_at, created_at), INTERVAL 3 YEAR)
        ELSE NULL
      END
  WHERE role = 'executive';

-- Step 3: Now lock the ENUM to only the three new roles
ALTER TABLE users
  MODIFY COLUMN role ENUM('founding_member','executive','professional')
    NOT NULL DEFAULT 'professional';

-- Step 4: Add index on membership_expires_at for fast expiry queries
CREATE INDEX idx_users_membership_expires ON users(membership_expires_at);
