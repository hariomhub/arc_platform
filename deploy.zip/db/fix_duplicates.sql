SET FOREIGN_KEY_CHECKS=0;

-- Remove duplicate team_members (keep lowest id per name)
DELETE t1 FROM team_members t1
INNER JOIN team_members t2
WHERE t1.id > t2.id AND t1.name = t2.name;

-- Remove duplicate resources (keep lowest id per title)
DELETE r1 FROM resources r1
INNER JOIN resources r2
WHERE r1.id > r2.id AND r1.title = r2.title;

-- Remove duplicate qna_posts (keep lowest id per title)
DELETE p1 FROM qna_posts p1
INNER JOIN qna_posts p2
WHERE p1.id > p2.id AND p1.title = p2.title;

SET FOREIGN_KEY_CHECKS=1;
