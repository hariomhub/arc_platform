SELECT 'events duplicates' AS chk, title, COUNT(*) c FROM events GROUP BY title HAVING c > 1
UNION ALL SELECT 'nominees duplicates', name, COUNT(*) FROM nominees GROUP BY name HAVING COUNT(*) > 1
UNION ALL SELECT 'resources duplicates', title, COUNT(*) FROM resources GROUP BY title HAVING COUNT(*) > 1
UNION ALL SELECT 'team duplicates', name, COUNT(*) FROM team_members GROUP BY name HAVING COUNT(*) > 1
UNION ALL SELECT 'awards duplicates', name, COUNT(*) FROM awards GROUP BY name HAVING COUNT(*) > 1
UNION ALL SELECT 'qna duplicates', title, COUNT(*) FROM qna_posts GROUP BY title HAVING COUNT(*) > 1;

SELECT '---FINAL COUNTS---' t, 0 n
UNION ALL SELECT 'team_members', COUNT(*) FROM team_members
UNION ALL SELECT 'events', COUNT(*) FROM events
UNION ALL SELECT 'nominees', COUNT(*) FROM nominees
UNION ALL SELECT 'resources', COUNT(*) FROM resources
UNION ALL SELECT 'awards', COUNT(*) FROM awards
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'qna_posts', COUNT(*) FROM qna_posts
UNION ALL SELECT 'qna_answers', COUNT(*) FROM qna_answers;
