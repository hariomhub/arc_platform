-- Fix admin password hash (Admin@123)
UPDATE users 
SET password_hash = '$2b$12$k8yzAUy4sehSiLrME5iVGORaj5mHwH3jdYwryio0i1Pu95XjC3E6S',
    role = 'admin',
    status = 'approved'
WHERE email = 'admin@arc.com';

SELECT email, LEFT(password_hash, 20) AS hash_preview, role, status FROM users WHERE email = 'admin@arc.com';
