ALTER TABLE nominees ADD COLUMN is_winner TINYINT(1) DEFAULT 0 AFTER is_active;
