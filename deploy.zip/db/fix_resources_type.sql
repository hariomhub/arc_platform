-- Expand resources.type ENUM to include all types the frontend supports
ALTER TABLE resources 
MODIFY COLUMN type ENUM('framework', 'whitepaper', 'product', 'video', 'article', 'tool', 'news') NOT NULL;

SELECT 'resources.type ENUM updated successfully.' AS status;
